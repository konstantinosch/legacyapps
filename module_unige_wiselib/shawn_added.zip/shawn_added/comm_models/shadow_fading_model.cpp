#include "sys/comm_models/shadow_fading_model.h"
#include "sys/node.h"
#include "sys/world.h"

#include <cassert>
#include <iostream>


#define BETA 1


using namespace std;

namespace shawn
{

   ShadowFadingModel::
   ShadowFadingModel()
      : initialized_ ( false ),
        range_       ( 1.0 ),
        has_range_   ( false )
   {}
   // ----------------------------------------------------------------------
   ShadowFadingModel::
   ~ShadowFadingModel()
   {}
   // ----------------------------------------------------------------------
   void
   ShadowFadingModel::
   init( void )
      throw()
   {
      CommunicationModel::init();
      initialized_ = true;
   }
   // ----------------------------------------------------------------------
   void
   ShadowFadingModel::
   set_transmission_range( double tr )
      throw()
   {
      assert( !initialized_ );
      range_ = tr;
      has_range_ = true;
      cout << "ShadowFadeModel: Transmission range set to ["<< range_ <<"]" << endl;
   }
   // ----------------------------------------------------------------------
   double
   ShadowFadingModel::
   transmission_range( void )
      const throw()
   {
      return range_;
   }
   // ----------------------------------------------------------------------
   bool
   ShadowFadingModel::
   can_communicate_bidi( const Node& u,
                         const Node& v )
      const throw()
   {		
	    double PX;
		double x= euclidean_distance( u.real_position(), v.real_position());
		double R = range_;

		if ( x < R )
		{
			PX = ( 1 - ( pow( x/R, 2*BETA ) /2 ) );
		}
		else if (x > 2*R)
		{ 
			PX = 0;	   
		}
		else if ( (x >= R) && (x < 2*R) ) 
		{
			PX = pow(((2*R - x)/R),2*BETA)/2;
		}
		return (rand()%100 < PX*100);
   }
   // ----------------------------------------------------------------------
   bool
   ShadowFadingModel::
   can_communicate_uni( const Node& u,
                        const Node& v )
      const throw()
   {
	   double PX;
		double x= euclidean_distance( u.real_position(), v.real_position());
		double R = range_;
		if ( x < R )
		{
			PX = ( 1 - ( pow( x/R, 2*BETA ) /2 ) );
		}
		else if (x > 2*R)
		{ 
			PX = 0;	   
		}
		else if ( (x >= R) && (x < 2*R) ) 
		{
			PX = pow(((2*R - x)/R),2*BETA)/2;
		}
		return (rand()%100 < PX*100);
   }
   // ----------------------------------------------------------------------
   bool
   ShadowFadingModel::
   exists_communication_upper_bound( void )
      const throw()
   {
      return true;
   }
   // ----------------------------------------------------------------------
   double
   ShadowFadingModel::
   communication_upper_bound( void )
      const throw()
   {
      return range_;
   }
   // ----------------------------------------------------------------------
   bool
   ShadowFadingModel::
   is_status_available_on_construction( void )
      const throw()
   {
      return true;
   }
   // ----------------------------------------------------------------------
   void 
   ShadowFadingModel::
   set_size_hint(double size_hint)
   throw()
   {
        if(has_range_) 
            return;

        has_range_ = true;
        range_ = size_hint;
        cout << "ShadowFadingModel: Using size hint ["<< range_ <<"] as comm range" << endl;
   }

}
