#ifndef __SHAWN_LEGACYAPPS_MODULE_UNIGE_PLANAR_GRAPH_EDGE_MODEL_FACTORY_H
#define __SHAWN_LEGACYAPPS_MODULE_UNIGE_PLANAR_GRAPH_EDGE_MODEL_FACTORY_H
#include "../buildfiles/_legacyapps_enable_cmake.h"
#ifdef ENABLE_MODULE_UNIGE_WISELIB
#include <string>

#include "sys/edge_models/edge_model_factory.h"


namespace shawn
{

   class PlanarGraphEdgeModelFactory
      : public EdgeModelFactory
   {
   public:
      PlanarGraphEdgeModelFactory();
      virtual ~PlanarGraphEdgeModelFactory();

      virtual std::string name( void ) const throw();
      virtual std::string description( void ) const throw();
      virtual EdgeModel* create( const SimulationController& ) throw();
   };



}

#endif
#endif
