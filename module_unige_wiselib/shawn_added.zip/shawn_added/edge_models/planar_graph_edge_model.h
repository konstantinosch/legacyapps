#ifndef __SHAWN_LEGACYAPPS_MODULE_UNIGE_PLANAR_GRAPH_EDGE_MODEL_H
#define __SHAWN_LEGACYAPPS_MODULE_UNIGE_PLANAR_GRAPH_EDGE_MODEL_H
#include "../buildfiles/_legacyapps_enable_cmake.h"
#ifdef ENABLE_MODULE_UNIGE_WISELIB
#include "sys/edge_models/manual_edge_model.h"
#include "sys/util/refcnt_pointer.h"
#include "sys/util/refcnt_pointable.h"
#include <sys/misc/dynamic_node_array.h>
#include <set>

namespace shawn
{

	class PlanarGraphEdgeModel
		: public ManualEdgeModel
	{
	public:
		DECLARE_HANDLES(NodeInfo);

		class NodeInfo
			: public RefcntPointable
		{ 
		public:

			Node* node_;
			bool comm_dir_[CD___DO_NOT_USE_COUNT__];

			NodeInfo(Node* node = NULL) 
				: node_(node) 
			{ 
				for(int i = 0; i < CD___DO_NOT_USE_COUNT__; ++i) 
					comm_dir_[i] = false; 
			}
			virtual ~NodeInfo();


			bool operator==(const NodeInfo& o) { return node_ == o.node_; }

			void update() 
			{ 
				comm_dir_[CD_ANY]  = comm_dir_[CD_IN] || comm_dir_[CD_OUT];
				comm_dir_[CD_BIDI] = comm_dir_[CD_IN] && comm_dir_[CD_OUT];    
			}
		};

		struct NodeInfoSort
		{ 
			bool operator() ( const NodeInfoHandle& n1, const NodeInfoHandle& n2 ) const
			{ 
				return n1->node_ < n2->node_; 
			}
		};

		typedef std::set<NodeInfoHandle, NodeInfoSort> NodeInfoSet;

	public:

		template<typename NodeType, typename NodeHoodIt> 
		class ListIteratorHelper
			: public AbstractIteratorHelper<NodeType>
		{
		public:

			typedef AbstractIteratorHelper<NodeType> base_type;

			ListIteratorHelper( const PlanarGraphEdgeModel& lm, EdgeModel::CommunicationDirection dir, NodeType& n, NodeHoodIt s, NodeHoodIt e );

			virtual ~ListIteratorHelper();

			virtual void init( void ) throw();

			virtual void next( void ) throw();

			virtual NodeType* current( void ) const throw();

			virtual AbstractIteratorHelper<NodeType>* clone( void ) const throw();

		private:
			const PlanarGraphEdgeModel& edge_model_;
			NodeHoodIt hood_it_;
			NodeHoodIt hood_end_it_;
			NodeType& node_;
		};

	public:

		PlanarGraphEdgeModel();

		virtual ~PlanarGraphEdgeModel();

		virtual void set_world( World& ) throw();

		virtual void add_edge( Node&, Node& ) throw();

		virtual void remove_dedge( Node&, Node& ) throw();

		virtual void add_dedge( Node&, Node& ) throw();

		virtual void node_added( Node& ) throw();

		virtual void node_removed( Node& ) throw();

		bool supports_mobility( void ) const throw();

		virtual int nof_adjacent_nodes( const Node&, EdgeModel::CommunicationDirection d = CD_BIDI  )  const throw();

		virtual const_adjacency_iterator begin_adjacent_nodes( const Node&, EdgeModel::CommunicationDirection d = CD_BIDI  ) const throw();

		virtual const_adjacency_iterator end_adjacent_nodes( const Node& ) const throw();

		virtual adjacency_iterator begin_adjacent_nodes_w( Node&, EdgeModel::CommunicationDirection d = CD_BIDI ) throw();

		virtual adjacency_iterator end_adjacent_nodes_w( Node& ) throw();

		virtual Box observer_initial_zone(Node&, const Vec& pos, const Vec& velo ) throw();

		Box observer_update_zone(Node&, const Vec& newpos, const Vec& velo ) throw();


	protected:

		PlanarGraphEdgeModel::NodeInfo& node_info(Node& u, Node& v);

		virtual void add_node_neighbors( Node& v, const Vec& pos, const Vec& velo) throw();

	private:

		DynamicNodeArray<NodeInfoSet>*  neighbors_;
		void planarize() throw();

	};

}

#endif
#endif
