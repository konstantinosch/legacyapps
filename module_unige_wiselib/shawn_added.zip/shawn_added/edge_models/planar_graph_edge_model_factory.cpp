#include "sys/edge_models/planar_graph_edge_model_factory.h"
#ifdef ENABLE_MODULE_UNIGE
#include "sys/edge_models/planar_graph_edge_model.h"
#include "sys/edge_models/edge_model_keeper.h"
#include "sys/simulation/simulation_controller.h"

namespace shawn
{

   PlanarGraphEdgeModelFactory::
   PlanarGraphEdgeModelFactory()
   {}

   PlanarGraphEdgeModelFactory::
   ~PlanarGraphEdgeModelFactory()
   {}

   std::string
   PlanarGraphEdgeModelFactory::
   name( void )
      const throw()
   {
      return std::string("planar");
   }

   std::string
   PlanarGraphEdgeModelFactory::
   description( void ) 
      const throw()
   {
      return std::string("A PlanarGraphEdgeModel");
   }

   EdgeModel*
   PlanarGraphEdgeModelFactory::
   create( const SimulationController& )
      throw()
   {
      return new PlanarGraphEdgeModel;
   }

}

#endif