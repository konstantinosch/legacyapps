#include "sys/edge_models/planar_graph_edge_model.h"
#ifdef ENABLE_MODULE_UNIGE
#include "sys/world.h"
#include "sys/communication_model.h"
#include "sys/misc/box.h"
#include "sys/node_movements/no_movement.h"
#include <iostream>
#include "sys/simulation/simulation_controller.h"

using namespace std;

namespace shawn
{

	template<typename NodeType, typename NodeHoodIt>
		shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType, NodeHoodIt>::
		ListIteratorHelper( const PlanarGraphEdgeModel& em, EdgeModel::CommunicationDirection dir, NodeType& n, NodeHoodIt it, NodeHoodIt endit )
		: AbstractIteratorHelper<NodeType>(dir),
		edge_model_( em ),
		hood_it_( it ),
		hood_end_it_( endit ),
		node_( n )
	{}

	template<typename NodeType, typename NodeHoodIt>
		shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType, NodeHoodIt>::
		~ListIteratorHelper()
	{}

	template<typename NodeType, typename NodeHoodIt>
		void
		shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType, NodeHoodIt>::
		init( void )
		throw()
	{
		while( hood_it_ != hood_end_it_ ) 
		{		
			if( (**hood_it_).comm_dir_[base_type::direction_] )
				break;
			++hood_it_; 
		}
	}

	template<typename NodeType, typename NodeHoodIt>
		void
		shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType, NodeHoodIt>::
		next( void )
		throw()
	{
		if( hood_it_ != hood_end_it_ ) 
		{
			++hood_it_;
			init();
		}
	}

	template<typename NodeType, typename NodeHoodIt>
		NodeType*
		shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType, NodeHoodIt>::
		current( void )
		const throw()
	{
		if( hood_it_ == hood_end_it_ )
			return NULL;
		else
			return (**hood_it_).node_;
	}

	template<typename NodeType,	typename NodeHoodIt>
		shawn::EdgeModel::AbstractIteratorHelper<NodeType>*
		shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType,NodeHoodIt>::
		clone( void )
		const throw()
	{
		return new shawn::PlanarGraphEdgeModel::ListIteratorHelper<NodeType,NodeHoodIt>
			( edge_model_, base_type::direction_, node_, hood_it_, hood_end_it_ );
	}

	template class shawn::PlanarGraphEdgeModel::ListIteratorHelper<Node,shawn::PlanarGraphEdgeModel::NodeInfoSet::iterator>;

	template class shawn::PlanarGraphEdgeModel::ListIteratorHelper<const Node, shawn::PlanarGraphEdgeModel::NodeInfoSet::const_iterator>;

	PlanarGraphEdgeModel::NodeInfo::~NodeInfo()
	{}

	PlanarGraphEdgeModel::PlanarGraphEdgeModel()
		: neighbors_( NULL )
	{}

	PlanarGraphEdgeModel::~PlanarGraphEdgeModel()
	{
		if( neighbors_ != NULL )
			delete neighbors_;
	}

	void PlanarGraphEdgeModel::set_world( World& w ) throw()
	{
		EdgeModel::set_world(w);
		if( neighbors_ != NULL )
			delete neighbors_;
		neighbors_ = new DynamicNodeArray<NodeInfoSet>(w);
	}

	Box	PlanarGraphEdgeModel::observer_initial_zone(Node& v, const Vec& pos, const Vec& velo ) throw()
	{
		assert( dynamic_cast<const NoMovement*>(&v.movement()) != NULL );
		neighbors_->node_added(v);

		if( communication_model().is_status_available_on_construction() )
			add_node_neighbors(v,pos,velo);
		
		const shawn::SimulationEnvironment& se = v.world().simulation_controller().environment();
		const int nodes = se.required_int_param( "count" );
		//printf("world().node_count() : %d\n",world().node_count());
		if (v.id()==nodes-1)
		{
			planarize();
		}

		return Box::INFINITE_3D_SPACE;
	}

	void PlanarGraphEdgeModel::	node_added(Node& n)	throw()
	{}

	void PlanarGraphEdgeModel::add_node_neighbors(Node& v, const Vec& pos, const Vec& velo)	throw()
	{
		for( World::node_iterator it = world_w().begin_nodes_w(), endit = world_w().end_nodes_w(); it != endit; ++it )
		{
			if( communication_model().can_communicate_uni(v, *it))
			{
				add_dedge(v, *it);
			}
			if( communication_model().can_communicate_uni(*it, v))
			{
				add_dedge(*it, v);
			}
		}
	}

   void PlanarGraphEdgeModel::add_edge( Node& u, Node& v ) throw()
   {
      if( communication_model().can_communicate_uni(u,v) )
         add_dedge(u,v);
      if( communication_model().can_communicate_uni(v,u) )
         add_dedge(v,u);
   }

   void PlanarGraphEdgeModel::add_dedge( Node& u, Node& v ) throw()
   {
		PlanarGraphEdgeModel::NodeInfo& uv = node_info(u, v);
		uv.comm_dir_[CD_OUT] = true;
		uv.update();
		PlanarGraphEdgeModel::NodeInfo& vu = node_info(v, u);
		vu.comm_dir_[CD_IN] = true;
		vu.update();
	}

	void PlanarGraphEdgeModel::remove_dedge( Node& u, Node& v ) throw()
	{
		PlanarGraphEdgeModel::NodeInfo& uv = node_info(u, v);
		uv.comm_dir_[CD_OUT] = false;
		uv.update();
		PlanarGraphEdgeModel::NodeInfo& vu = node_info(v, u);
		vu.comm_dir_[CD_IN] = false;
		vu.update();
	}

	int	PlanarGraphEdgeModel::nof_adjacent_nodes( const Node& v, CommunicationDirection d  ) const throw()
	{
		if (d == CD_ANY) 
		{
			assert( neighbors_ != NULL );
			return (*neighbors_)[v].size();
		}
		else
		{
			int count = 0;
			for (EdgeModel::const_adjacency_iterator it = begin_adjacent_nodes(v, d), endit = end_adjacent_nodes(v); it!=endit;++it) 
				count++;
			return count;
		}
	}

	
	EdgeModel::const_adjacency_iterator	PlanarGraphEdgeModel::begin_adjacent_nodes(const Node& v, CommunicationDirection d)	const throw()
	{
		assert( neighbors_ != NULL );
		NodeInfoSet& s = (*neighbors_)[v];

		return EdgeModel::const_adjacency_iterator( 
			new PlanarGraphEdgeModel::ListIteratorHelper<const Node, NodeInfoSet::const_iterator>
			( *this, d, v,  s.begin(), s.end() ) );
	}

	EdgeModel::const_adjacency_iterator PlanarGraphEdgeModel::end_adjacent_nodes( const Node& )	const throw()
	{
		return EdgeModel::const_adjacency_iterator( NULL );
	}

	EdgeModel::adjacency_iterator PlanarGraphEdgeModel::begin_adjacent_nodes_w( Node& v, CommunicationDirection d )	throw()
	{
		assert( neighbors_ != NULL );
		NodeInfoSet& s = (*neighbors_)[v];

		return EdgeModel::adjacency_iterator
			( new PlanarGraphEdgeModel::ListIteratorHelper<Node, NodeInfoSet::iterator >
			( *this, d, v, s.begin(), s.end() ) );
	}

	EdgeModel::adjacency_iterator PlanarGraphEdgeModel::end_adjacent_nodes_w( Node& v )	throw()
	{
		return EdgeModel::adjacency_iterator( NULL );
	}

	PlanarGraphEdgeModel::NodeInfo&	PlanarGraphEdgeModel::node_info(Node& u, Node& v)
	{
		assert( neighbors_ != NULL );
		NodeInfoSet& l = (*neighbors_)[u];
		NodeInfoHandle seek=new NodeInfo; seek->node_=&v;
		NodeInfoSet::iterator pos = l.find(seek);
		if( pos == l.end() ) 
		{
			NodeInfo* ni = new NodeInfo;
			ni->node_ = &v;
			l.insert(ni);
			return *ni;
		}

		return **pos;
	}

	Box	PlanarGraphEdgeModel::observer_update_zone(Node& v, const Vec& newpos, const Vec& velo ) throw()
	{
		assert( velo.euclidean_norm() < EPSILON);
		return Box::INFINITE_3D_SPACE;;
	}

	bool PlanarGraphEdgeModel::supports_mobility( void ) const throw()
	{
		return false;
	}

	void PlanarGraphEdgeModel::node_removed(Node& node)	throw()
	{
		assert( neighbors_ != NULL );

		NodeInfo ni;
		ni.node_ = &node;
		NodeInfoHandle nih(&ni);

		for( adjacency_iterator  it  = begin_adjacent_nodes_w(node),  end = end_adjacent_nodes_w(node); it!=end; ++it )
			(*neighbors_)[*it].erase( nih );

		(*neighbors_).node_removed( node );
	}

	void PlanarGraphEdgeModel::planarize() throw()
	{
		for ( World::node_iterator v = world_w().begin_nodes_w(), endv = world_w().end_nodes_w(); v != endv; ++v )
		{	
			for ( World::node_iterator it = world_w().begin_nodes_w(), endit = world_w().end_nodes_w(); it != endit; ++it )
			{
				if ((communication_model().can_communicate_uni(*it,*v)) &&
				    (communication_model().can_communicate_uni(*v,*it)) &&
				    (it->id()!=v->id()))
				{
					for ( World::node_iterator jt = world_w().begin_nodes_w(), endjt = world_w().end_nodes_w(); jt != endjt; ++jt )
					{
						if ( (communication_model().can_communicate_uni(*it,*jt)) &&
							 (communication_model().can_communicate_uni(*jt,*it)) &&
							 (it->id() != jt->id()) && 
							 (jt->id() != v->id()) )
						{
							double itjt_square_distance = pow( euclidean_distance( it->real_position(), jt->real_position() ), 2 );
							double itv_square_distance = pow( euclidean_distance( it->real_position(), v->real_position() ), 2 );
							double jtv_square_distance = pow( euclidean_distance( jt->real_position(), v->real_position() ), 2 );
							if  (( itjt_square_distance) >= ( itv_square_distance + jtv_square_distance ))
							{
								remove_dedge(*it,*jt);
								remove_dedge(*jt,*it);
							}
						}
					}
				}
			}
		}
	}

}
#endif





